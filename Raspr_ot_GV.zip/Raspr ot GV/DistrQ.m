function Qmin = DistrQ( P )

global T1_P T1_Q T2_P T2_Q;
global n1 n;

Qmin=0;
for i=1:n
%     if E(i)==1
        if i<=n1
            Qmin = Qmin + spline(T1_P,T1_Q,P(i));
        else
            Qmin = Qmin + spline(T2_P,T2_Q,P(i));
        end
%     end
end

end

