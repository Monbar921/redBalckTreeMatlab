close all; clear all;
load ('NHPP_dq.mat')
global T1_P T1_dQ T2_P T2_dQ T1_Q T2_Q;
Hbr = 14;
K_wp = 2.078e-06;
P1s = 50;
P2s = 50;
Q1s = interp2(units(1).Ht_Q,units(1).N,units(1).Q,Hbr,P1s);
Q2s = interp2(units(3).Ht_Q,units(3).N,units(3).Q,Hbr,P2s);
Hnet1 = Hbr - K_wp*Q1s^2;
Hnet2 = Hbr - K_wp*Q2s^2;

T1_P  = [ 20 25 30 35 40 45 50 55 60 65 70];
size_T1_P = size (T1_P);
for i=1:size_T1_P(2)
    T1_Q(i) = interp2(units(1).Ht_Q,units(1).N,units(1).Q,Hnet1,T1_P(i));
    T1_dQ(i) = interp2(units(1).Ht_dq,units(1).N,units(1).dq,Hnet1,T1_P(i));
end    
% T1_Q  = [ 150.53 183.19 217.58 252.4 288.62 325.62 364.29 406.29 457.81 509 561 ];
% T1_dQ = [ 6.424 6.641 6.858 7.075 7.292 7.509 8.000 9.200 11.50 13.8 16.1 ];

T2_P =  [ 30 35 40 45 50 55 60 65 70 75 80 ];
%T2_Q =  [ 218 252 288 324 363 401 436 470 505 540 575 ];
% T2_Q =  [ 218 250.68 285.29 321.905 358.515 398.13 436.74 472.355 508 546 586 ];
% T2_dQ = [ 6.536 6.658 6.781 6.903 7.026 7.148 7.271 7.600 8.200 9.200 11.50 ];
size_T2_P = size (T2_P);
for i=1:size_T2_P(2)
    T2_Q(i) = interp2(units(3).Ht_Q,units(2).N,units(3).Q,Hnet2,T2_P(i));
    T2_dQ(i) = interp2(units(3).Ht_dq,units(2).N,units(3).dq,Hnet2,T2_P(i));
end 
Pmax1=65;  Pmax2=75;

T1_P_Graph = 20:0.1:70;
T1_Q_Graph  = spline( T1_P, T1_Q,  T1_P_Graph );
T1_dQ_Graph = spline( T1_P, T1_dQ, T1_P_Graph );

T2_P_Graph = 30:0.1:80;
T2_Q_Graph  = spline( T2_P, T2_Q,  T2_P_Graph );
T2_dQ_Graph = spline( T2_P, T2_dQ, T2_P_Graph );

% figure(1);
% plot( T1_P_Graph, T1_Q_Graph, '-r', T2_P_Graph, T2_Q_Graph, '-b' );
% xlim([30 75]);
% grid on;
% 
% figure(2);
% plot( T1_P_Graph, T1_dQ_Graph, '-r', T2_P_Graph, T2_dQ_Graph, '-b' );
% xlim([30 75]);
% ylim([6 14]);
% grid on;



global Pd Ps n1 n2 n E;
Ps=162;  n1=2;  n2=1;  n=n1+n2;
Pmax(1)=Pmax1;  Pmax(2)=Pmax2;  Pmax(3)=Pmax2;
Start = cputime; 
Pz = [0 0 0];
% for i = 1:15
%     for j = 1:15
% %         for k = 1:15
%             P_p = [5*i 5*j];
%             Q_plot(i,j) = DistrQ (P_p);
%         end
%     end
% end
% figure
% surf (P_p(1,:,:)Q_plot)
Pd=Ps;
for i=1:n
    E(i)=1;
end

for k=1:10
    bo = fzero( @DistrF, 7 );
    C=0;  ESum=0;
    for i=1:n
        if E(i)==1
            if i<=n1
              Po(i)=spline(T1_dQ,T1_P,bo);
            else
              Po(i)=spline(T2_dQ,T2_P,bo);
            end
            if Po(i) > Pmax(i)
                Po(i)=Pmax(i);  C=1;  Pd=Pd-Po(i);  E(i)=0;
            end
        end
        ESum=ESum+E(i);
    end
    if C==0 || ESum==0
        break;
    end
end

Elapsed = cputime - Start 
k
Po
E
Pr = Ps/n;
Q1 = interp1 (T1_P,T1_Q,Po(1));
Q3 = interp1 (T2_P,T2_Q,Po(3));
Q1r = interp1 (T1_P,T1_Q,Pr);
Q3r = interp1 (T2_P,T2_Q,Pr);
Qsumr = n1*Q1r+n2*Q3r; 
Qsum = n1*Q1+n2*Q3; 
dQs =(Qsum-Qsumr)/Qsumr*100;

b1 = spline( T1_P, T1_dQ, Po(1) )
b3 = spline( T2_P, T2_dQ, Po(3) )

figure(1);
plot( T1_P, T1_Q, '-r', T2_P, T2_Q, '--b');
xlim([30 75]);
ylim([100 800]);
grid on;
b1_ = repmat( b1, size(T1_P) );
b3_ = repmat( b3, size(T2_P) );
figure(2);
plot( T1_P, T1_dQ, '-r', T2_P, T2_dQ, '--b',T2_P, b3_,'-.r');
xlabel ('P_{����} (���)'); ylabel ('b (�3/�*���)'); legend ('��-661-��-800','��30/3295-�-800','b0','Location', 'northeast');
xlim([30 75]);
ylim([6 14]);
grid on;
A = [];
B = [];
Aeq = [1 1 1; 0 0 0; 0 0 0];
Beq = [Ps 0 0];
tic
grid on
gaoptions = gaoptimset('SelectionFcn', @selectionstochunif,'CreationFcn',@gacreationlinearfeasible, 'MutationFcn',@mutationadaptfeasible,'PopulationSize', 25, 'FitnessLimit', 1400, 'PlotFcn',{@gaplotbestf,@gaplotstopping}); 
% gaoptions = gaoptimset('SelectionFcn', @selectionstochunif,'CreationFcn',@gacreationlinearfeasible,'TolCon', 1e-1, 'TolFun', 1e-1, 'MutationFcn',@mutationadaptfeasible,'PopulationSize', 25, 'Generations', 15, 'PlotFcn',{@gaplotbestf,@gaplotstopping,@gaplotselection}); 
% gaoptions = gaoptimset('CreationFcn',@gacreationlinearfeasible,'TolCon', 1e-6, 'TolFun', 1e-6, 'MutationFcn',@mutationadaptfeasible,'PopulationSize', 15, 'Generations', 15, 'PlotFcn',{@gaplotbestf,@gaplotstopping}); 
[Pq,Qsum_min,exitFlag,Output] = ga(@DistrQ, n,A,B,Aeq,Beq, [0 0 0], [Pmax(1) Pmax(2) Pmax(3)],[],gaoptions);


grid on
fprintf('The number of generations was : %d\n', Output.generations);
fprintf('The number of function evaluations was : %d\n', Output.funccount);
fprintf('The best function value found was : %g\n', Qsum_min);
toc
 
dQg =(Qsum_min-Qsumr)/Qsumr*100;

% Aeq = [1 1 1];
% beq = Ps;
% LB = [0 0 0];
% UB = [Pmax(1) Pmax(2) Pmax(3)];
% tic
% options = psooptimset('Vectorized','on','ConstrBoundary' ,'soft','PopInitRange',[20 20 20;65 65 65],'CognitiveAttraction',3,'SocialAttraction', 0.1,'Display', 'diagnose','ParticleInertia', 0.1, 'PopulationSize',100,'InitialVelocities', [40 40 40], 'KnownMin', [44.560954850575220 44.560954850575220 70.878090298849560], 'InitialPopulation', [40 40 40],'PlotFcns', {@psoplotbestf,@psoplotswarmsurf})
% [Pq2,Qsum_min2,exitflag,output,population,scores] = pso(@DistrQ, n,[],[],Aeq,beq, LB, UB,[],options);
% toc


%% %%
tic
% options = optimoptions(@fmincon,'Algorithm','interior-point','HessianApproximation', 'bfgs','Display','iter','MaxIterations',10, 'PlotFcn',{@optimplotx,...
%     @optimplotfval,@optimplotfirstorderopt})
options = optimoptions(@fmincon,'Algorithm','interior-point','HessianApproximation', 'bfgs','Display','iter','MaxIterations',10, 'PlotFcn',{@optimplotfval})
problem.fitnessfcn	= @DistrQ;
problem.x0 = [1 1 1];
problem.A = [];
problem.b		= [];
problem.Aeq		= Aeq;
problem.beq		= Beq;
problem.lb			= [0 0 0];
problem.ub			= [Pmax(1) Pmax(2) Pmax(3)];
% problem.nonlcon		= @mynonlcon;
problem.options		= options;
[Pq3,Qsum_min3,exitflag,output] = fmincon(@DistrQ,[0 0 0],[],[],Aeq,Beq,[0 0 0],[Pmax(1) Pmax(2) Pmax(3)],[],options);
% [Pq3,Qsum_min3,exitflag,output] = fmincon(problem);
toc
dQi =(Qsum_min3-Qsumr)/Qsumr*100;
%%
% addpath(genpath('pso'))
% 
% % Options
% options = pso;
% options.PopulationSize	= 24;
% options.Vectorized		= 'on';
% options.BoundaryMethod	= 'penalize';
% options.PlotFcns		= @psoplotbestf;
% options.Display			= 'iter';
% % options.HybridFcn		= @fmincon;
% 
% 
% % Problem
% problem	= struct;
% problem.fitnessfcn	= @DistrQ;
% problem.nvars		= 3;
% % Aeq = [1 1 1];
% % beq = Ps;
% % problem.Aineq		= Aeq;
% % problem.bineq		= Beq;
% problem.Aeq		= Aeq;
% problem.beq		= Beq';
% problem.lb			= [-1000 -1000 -1000];
% problem.ub			= [Pmax(1) Pmax(2) Pmax(3)];
% % problem.nonlcon		= @mynonlcon;
% problem.options		= options;
% tic 
% % Optimize
% [Pq3,Qsum_min3,exitflag,output] = pso(problem);
% toc
% Q1 = interp1 (T1_P,T1_Q,Pq3(1));
% Q2 = interp1 (T1_P,T1_Q,Pq3(2));
% Q3 = interp1 (T2_P,T2_Q,Pq3(3));
% Qsum3 = Q1+Q2 +Q3; 