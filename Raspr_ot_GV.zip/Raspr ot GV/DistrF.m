function D = DistrF( b )

global T1_P T1_dQ T2_P T2_dQ;
global Pd n1 n2 n E;

PSum=0;
for i=1:n
    if E(i)==1
        if i<=n1
            PSum = PSum + spline(T1_dQ,T1_P,b);
        else
            PSum = PSum + spline(T2_dQ,T2_P,b);
        end
    end
end

D = PSum-Pd;

end

