function f = DistrQ_PSO( P )

global T1_P T1_Q T2_P T2_Q;
global Ps n1 n;

Qmin=0;
for i=1:n
%     if E(i)==1
        if i<=n1
            Qmin = Qmin + spline(T1_P,T1_Q,P(i));
        else
            Qmin = Qmin + spline(T2_P,T2_Q,P(i));
        end
%     end
end
c0=[];

c0(1)=P(1)+P(2)+P(3)-Ps;
for i=1:length(c0)
 if c0(i)>0
 c(i)=1;
 else
 c(i)=0;
 end
end
penalty=10000; % penalty on each constraint violation
f=Qmin+penalty*sum(c); 
end

