clear all;
filename1 = 'NHPP_dq';

k=6;
f=3;
for j=1:f
    for i=1:k
        xlRange_Q = ['C' num2str(2+i) ':P' num2str(2+i)]; 
        units(j).Q(:,i) = xlsread(filename1, j, xlRange_Q);
        xlRange_dq = ['C' num2str(12+i) ':P' num2str(12+i)]; 
        units(j).dq(:,i) = xlsread(filename1, j, xlRange_dq);
        xlRange_Ht_Q = ['B' num2str(2+i)];
        units(j).Ht_Q(i) = xlsread(filename1, j, xlRange_Ht_Q);
        xlRange_Ht_dq = ['B' num2str(12+i)];
        units(j).Ht_dq(i) = xlsread(filename1, j, xlRange_Ht_dq);
        xlRange_Ht_dq = ['B' num2str(12+i)];
        xlRange_N = 'C2:P2'; 
        units(j).N = xlsread(filename1, j, xlRange_N);
    end
end
save ('NHPP_dq','units'); 
load ('NHPP_dq.mat')