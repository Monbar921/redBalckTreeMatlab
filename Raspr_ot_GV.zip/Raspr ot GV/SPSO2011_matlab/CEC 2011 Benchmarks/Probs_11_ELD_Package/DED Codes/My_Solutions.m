clc; clear all;
%%
% 5 Unit Limits
% Pmin = [10,20,30,40,50;];              Pmax = [75,125,175,250,300;]; 
% Lower_Limit = repmat(Pmin,1,24);       Upper_Limit= repmat(Pmax,1,24);

% 10 Unit Limits
% Pmin = [150,135,73,60,73,57,20,47,20];  Pmax = [470,460,340,300,243,160,130,120,80]; %% 10 UNIT Limits
% Lower_Limit = repmat(Pmin,1,24);        Upper_Limit= repmat(Pmax,1,24);

