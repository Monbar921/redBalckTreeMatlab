function r= alea (a,b)
% Random real  number between a and b
    
    r= a + rand*(b - a); 
 
end

